export type User = {
  id: string;
  username: string;
  name: string;
  role: string;
  roleCode: string;
};
