import { config } from 'dotenv';
config();

import '@/ai/flows/generate-user-avatar.ts';