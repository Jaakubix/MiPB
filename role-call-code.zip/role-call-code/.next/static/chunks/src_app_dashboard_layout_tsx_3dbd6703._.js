(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d8f5171e._.js",
  "static/chunks/src_af077965._.js"
],
    source: "dynamic"
});
