(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_126bf4e8._.js",
  "static/chunks/src_dea300a0._.js"
],
    source: "dynamic"
});
